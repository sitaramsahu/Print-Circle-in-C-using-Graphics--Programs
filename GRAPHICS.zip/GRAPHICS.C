		// Question 01: Draw a circle in c using Graphics

#include<graphics.h>
#include<stdio.h>

int main()
{
   int gd = DETECT, gm;
   initgraph(&gd, &gm, "c:\\TURBOC3\\BGI\\"); // initialize graphics

  setcolor(RED); // set color to blue
  circle(200, 200, 150);//draw circle with center at (200, 200) and radius 150

    getch(); // wait for user input
    closegraph(); // close graphics
    return 0;
}


	// SUBSCRIBE YouTube Channel CPPWITHSITARAMSAHU